//
//  AnimalTableViewController.swift
//  SearchPet
//
//  Created by KPUGAME on 2019. 6. 2..
//  Copyright © 2019년 BAEJISOO. All rights reserved.
//

import UIKit

class AnimalTableViewController: UITableViewController, XMLParserDelegate {

    @IBOutlet var tbData: UITableView!
    
    //Done버튼을 누르면 동작하는 unwind메소드
    //아무 동작도 하지 않지만 이 메소드가 있어야지 AnimalDetailTableViewController에서 unwind 연결이 가능함
    @IBAction func doneToAnimalTableViewController(segue:UIStoryboardSegue){
        
    }
    
    //ViewController로 부터 segue를 통해 전달받은 OpenAPI url 주소
    var url : String?
    //xml파일을 다운로드 및 파싱하는 오브젝트
    var parser = XMLParser()
    var posts = NSMutableArray()
    
    var elements = NSMutableDictionary()
    var element = NSString()
    
    var kindCd = NSMutableString()
    var noticeEdt = NSMutableString()
    var orgNm = NSMutableString()
    var happenPlace = NSMutableString()
    var imageurl = NSMutableString()
    var noticeNo = NSMutableString()
    
    // 유기동물 공고번호 변수와 utf8 변수 추가
    var noticeNum = ""
    var noticeNum_utf8 = ""
    
    func beginParsing()
    {
        posts = []
        //parser = XMLParser(contentsOf:(URL(string:"http://images.apple.com/main/rss/hotnews/hotnews.rss"))!)! // 공공데이터 데이터마다 달라지는 url
        parser = XMLParser(contentsOf: (URL(string: url!))!)!
        //print("viewController url: ")
        //print(String(url!))
        parser.delegate = self
        parser.parse()
        tbData!.reloadData()
    }
    
    //parser가 새로운 element를 발견하면 변수를 생성한다.
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String])
    {
        element = elementName as NSString
        
        if (elementName as String).isEqual("item") // url마다 item date pubdata 명칭들이 각각 다름
        {
            elements = NSMutableDictionary()
            elements = [:]
            kindCd = NSMutableString()
            kindCd = ""
            noticeEdt = NSMutableString()
            noticeEdt = ""
            orgNm = NSMutableString()
            orgNm = ""
            happenPlace = NSMutableString()
            happenPlace = ""
            noticeNo = NSMutableString()
            noticeNo = ""
            // 유기동물 이미지 파일 url
            imageurl = NSMutableString()
            imageurl = ""
        }
    }
    func parser(_ parser:XMLParser, foundCharacters string: String)
    {
        if element.isEqual(to: "kindCd") {
            kindCd.append(string)
        } else if element.isEqual(to: "noticeEdt") {
            noticeEdt.append(string)
        } else if element.isEqual(to: "orgNm") {
            orgNm.append(string)
        } else if element.isEqual(to: "happenPlace") {
            happenPlace.append(string)
        } else if element.isEqual(to: "noticeNo") {
            noticeNo.append(string)
        } else if element.isEqual(to: "filename") {
            imageurl.append(string)
        }
    }
    //element의 끝에서 feed데이터를 dictionary에 저장
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?)
    {
        if (elementName as NSString).isEqual(to: "item")
        {
            if (!kindCd.isEqual(nil)) {
                elements.setObject(kindCd, forKey: "kindCd" as NSCopying)
            }
            if (!noticeEdt.isEqual(nil)) {
                elements.setObject(noticeEdt, forKey: "noticeEdt" as NSCopying)
            }
            if (!orgNm.isEqual(nil)) {
                elements.setObject(orgNm, forKey: "orgNm" as NSCopying)
            }
            if (!happenPlace.isEqual(nil)) {
                elements.setObject(happenPlace, forKey: "happenPlace" as NSCopying)
            }
            if (!noticeNo.isEqual(nil)) {
                elements.setObject(noticeNo, forKey: "noticeNo" as NSCopying)
            }
            if (!imageurl.isEqual(nil)) {
                elements.setObject(imageurl, forKey: "imageurl" as NSCopying)
            }
            posts.add(elements)
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segueToAnimalDetail" {
            if let cell = sender as? UITableViewCell {
                let indexPath = tableView.indexPath(for: cell)
                noticeNum = (posts.object(at: (indexPath?.row)!) as AnyObject).value(forKey: "noticeNo") as! NSString as String
                //url에서 한글을 쓸 수 있도록 코딩
                noticeNum_utf8 = noticeNo.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
                //선택한 row의 공고번호를 추가하여 url 구성하고 넘겨줌
                if let navController = segue.destination as? UINavigationController {
                    if let detailAnimalTableViewController = navController.topViewController as?
                        DetailAnimalTableViewController {
                        detailAnimalTableViewController.url = url! + "&noticeNo=" + noticeNum_utf8
                    }
                }
                
            }
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        //XML 파싱
        beginParsing()
    }

    // MARK: - Table view data source
    //테이블의 Section 개수 = 1
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    //row의 개수는 posts 배열 원소의 개수
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return posts.count
    }

    //테이블뷰 셀의 내용은 title과 subtitle을 posts 배열 원소(dictionary)에서 yadmNm과 addr에 해당하는 value로 설정
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        cell.textLabel?.text = (posts.object(at: indexPath.row) as AnyObject).value(forKey: "kindCd") as! NSString as String
        cell.detailTextLabel?.text = (posts.object(at: indexPath.row) as AnyObject).value(forKey: "happenPlace") as! NSString as String
        if let url = URL(string: (posts.object(at: indexPath.row) as AnyObject).value(forKey: "imageurl") as! NSString as String)
        {
            if let data = try? Data(contentsOf: url)
            {
                cell.imageView?.image = UIImage(data: data)
            }
        }
        return cell
    }


}
