//
//  DetailAnimalTableViewController.swift
//  SearchPet
//
//  Created by KPUGAME on 2019. 6. 2..
//  Copyright © 2019년 BAEJISOO. All rights reserved.
//

import UIKit

class DetailAnimalTableViewController: UITableViewController, XMLParserDelegate {

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet var detailTableView: UITableView!
    
    //Done버튼을 누르면 동작하는 unwind메소드
    //아무 동작도 하지 않지만 이 메소드가 있어야지 MapViewController에서 unwind 연결이 가능함
    @IBAction func doneToDetailAnimalViewController(segue:UIStoryboardSegue){
        
    }
    
    //AnimalTableViewController로 부터 segue를 통해 전달받은 OpenAPI url 주소
    var url : String?
    
    var parser = XMLParser()
    let postsname : [String] = ["상태", "품종", "성별", "중성화여부", "색", "나이", "몸무게", "공고번호", "발견장소", "특이사항", "보호센터", "보호센터 주소", "담당부서", "이미지주소"]
    var posts : [String] = ["", "", "", "", "", "", "", "", "", "", "", "", "", ""]
    var element = NSString()
    var processState = NSMutableString()
    var kindCd = NSMutableString()
    var sexCd = NSMutableString()
    var neuterYn = NSMutableString()
    var colorCd = NSMutableString()
    var age = NSMutableString()
    var weight = NSMutableString()
    var noticeNo = NSMutableString()
    var happenPlace = NSMutableString()
    var specialMark = NSMutableString()
    var careNm = NSMutableString()
    var careAddr = NSMutableString()
    var orgNm = NSMutableString()
    var popfile = NSMutableString()
    
    var image: String = ""
    var name: String = ""
    var address: String = ""
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any!) {
        if segue.identifier == "segueToMapView" {
            if let mapViewController = segue.destination as? MapViewController {
                mapViewController.careAddr = address
                mapViewController.careNm = name
            }
        }
    }
    func beginParsing()
    {
        posts = []
        parser = XMLParser(contentsOf: (URL(string: url!))!)!
        print("detailAnimalTableViewController URL: ")
        print(String(url!))
        parser.delegate = self
        parser.parse()
        detailTableView!.reloadData()
    }
    //parser가 새로운 element를 발견하면 변수를 생성한다.
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String])
    {
        element = elementName as NSString
        if (elementName as NSString).isEqual(to: "item") // url마다 item date pubdata 명칭들이 각각 다름
        {
            posts = ["", "", "", "", "", "", "", "", "", "", "", "", "", ""]
            
            processState = NSMutableString()
            processState = ""
            kindCd = NSMutableString()
            kindCd = ""
            sexCd = NSMutableString()
            sexCd = ""
            neuterYn = NSMutableString()
            neuterYn = ""
            colorCd = NSMutableString()
            colorCd = ""
            age = NSMutableString()
            age = ""
            weight = NSMutableString()
            weight = ""
            noticeNo = NSMutableString()
            noticeNo = ""
            happenPlace = NSMutableString()
            happenPlace = ""
            specialMark = NSMutableString()
            specialMark = ""
            careNm = NSMutableString()
            careNm = ""
            careAddr = NSMutableString()
            careAddr = ""
            orgNm = NSMutableString()
            orgNm = ""
            
            // 유기동물 이미지 파일 url
            popfile = NSMutableString()
            popfile = ""
            
            //imageurl = NSMutableString()
            //imageurl = ""
        }
    }
    func parser(_ parser:XMLParser, foundCharacters string: String)
    {
        if element.isEqual(to: "processState") {
            processState.append(string)
        } else if element.isEqual(to: "kindCd") {
            kindCd.append(string)
        } else if element.isEqual(to: "sexCd") {
            sexCd.append(string)
        } else if element.isEqual(to: "neuterYn") {
            neuterYn.append(string)
        } else if element.isEqual(to: "colorCd") {
            colorCd.append(string)
        } else if element.isEqual(to: "age") {
            age.append(string)
        } else if element.isEqual(to: "weight") {
            weight.append(string)
        } else if element.isEqual(to: "noticeNo") {
            noticeNo.append(string)
        } else if element.isEqual(to: "happenPlace") {
            happenPlace.append(string)
        } else if element.isEqual(to: "specialMark") {
            specialMark.append(string)
        } else if element.isEqual(to: "careNm") {
            careNm.append(string)
        } else if element.isEqual(to: "careAddr") {
            careAddr.append(string)
        } else if element.isEqual(to: "orgNm") {
            orgNm.append(string)
        } else if element.isEqual(to: "popfile") {
            popfile.append(string)
        }
    }
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?)
    {
        if (elementName as NSString).isEqual(to: "item") {
            if !processState.isEqual(nil) {
                posts[0] = processState as String
            }
            if !kindCd.isEqual(nil) {
                posts[1] = kindCd as String
            }
            if !sexCd.isEqual(nil) {
                posts[2] = sexCd as String
            }
            if !neuterYn.isEqual(nil) {
                posts[3] = neuterYn as String
            }
            if !colorCd.isEqual(nil) {
                posts[4] = colorCd as String
            }
            if !age.isEqual(nil) {
                posts[5] = age as String
            }
            if !weight.isEqual(nil) {
                posts[6] = weight as String
            }
            if !noticeNo.isEqual(nil) {
                posts[7] = noticeNo as String
            }
            if !happenPlace.isEqual(nil) {
                posts[8] = happenPlace as String
            }
            if !specialMark.isEqual(nil) {
                posts[9] = specialMark as String
            }
            if !careNm.isEqual(nil) {
                posts[10] = careNm as String
            }
            if !careAddr.isEqual(nil) {
                posts[11] = careAddr as String
            }
            if !orgNm.isEqual(nil) {
                posts[12] = orgNm as String
            }
            if !popfile.isEqual(nil) {
                posts[13] = popfile as String
                image = popfile as String
                if let url = URL(string: posts[13] as String) {
                    if let data = try? Data(contentsOf: url) {
                        imageView?.image = UIImage(data: data)
                    }
                }
            }
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        beginParsing()
        

    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return posts.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AnimalCell", for: indexPath)
        cell.textLabel?.text = postsname[indexPath.row] // 13개 정보 타이틀
        cell.detailTextLabel?.text = posts[indexPath.row]
        return cell
    }
    
}
