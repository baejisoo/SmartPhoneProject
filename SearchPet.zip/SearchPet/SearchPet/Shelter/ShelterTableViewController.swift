//
//  DogTableViewController.swift
//  SearchPet
//
//  Created by KPUGAME on 2019. 6. 2..
//  Copyright © 2019년 BAEJISOO. All rights reserved.
//

import UIKit

class ShelterTableViewController: UITableViewController, XMLParserDelegate {

    @IBOutlet var tbData: UITableView!
    var keyword : String?
    
    //ViewController로 부터 segue를 통해 전달받은 OpenAPI url 주소
    var url : String?
    //xml파일을 다운로드 및 파싱하는 오브젝트
    var parser = XMLParser()
    var posts = NSMutableArray()
    
    var elements = NSMutableDictionary()
    var element = NSString()
    
    var careNm = NSMutableString()
    var careAddr = NSMutableString()
    
    func beginParsing()
    {
        posts = []
        //parser = XMLParser(contentsOf:(URL(string:"http://images.apple.com/main/rss/hotnews/hotnews.rss"))!)! // 공공데이터 데이터마다 달라지는 url
        parser = XMLParser(contentsOf: (URL(string: url!))!)!
        print("viewController url: ")
        print(String(url!))
        parser.delegate = self
        parser.parse()
        tbData!.reloadData()
    }
    
    //parser가 새로운 element를 발견하면 변수를 생성한다.
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String])
    {
        element = elementName as NSString
        
        if (elementName as String).isEqual("item") // url마다 item date pubdata 명칭들이 각각 다름
        {
            elements = NSMutableDictionary()
            elements = [:]
            careNm = NSMutableString()
            careNm = ""
            careAddr = NSMutableString()
            careAddr = ""
        }
    }
    func parser(_ parser:XMLParser, foundCharacters string: String)
    {
        if element.isEqual(to: "careNm") {
            careNm.append(string)
        } else if element.isEqual(to: "careAddr") {
            careAddr.append(string)
        }
    }
    //element의 끝에서 feed데이터를 dictionary에 저장
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?)
    {
        if (elementName as NSString).isEqual(to: "item")
        {
            if (!careNm.isEqual(nil)) {
                elements.setObject(careNm, forKey: "careNm" as NSCopying)
            }
            if (!careAddr.isEqual(nil)) {
                elements.setObject(careAddr, forKey: "careAddr" as NSCopying)
            }
            
            posts.add(elements)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        //XML 파싱
        beginParsing()
        if keyword != "" {
            filterData()
        }
    }

    @IBAction func doneToShelterTableViewController(segue:UIStoryboardSegue) {
        
    }
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return posts.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        cell.textLabel?.text = (posts.object(at: indexPath.row) as AnyObject).value(forKey: "careNm") as! NSString as String
        cell.detailTextLabel?.text = (posts.object(at: indexPath.row) as AnyObject).value(forKey: "careAddr") as! NSString as String
        return cell
    }

    
    func filterData() {
        let predicate = NSPredicate(format: "SELF.careNm contains %@", keyword!)
        posts = NSMutableArray(array : posts.filter { predicate.evaluate(with: $0) })
    }
}
