//
//  ViewController.swift
//  SearchPet
//
//  Created by KPUGAME on 2019. 5. 15..
//  Copyright © 2019년 BAEJISOO. All rights reserved.
//
// OpenAPI 서울시 보호소정보
// 서울시 관악구/광진구/구로구/금천구 보호소 10개 TableView에 리스트 표시하고 MapKit을 이용하여 지도표시
import UIKit
import Speech

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, XMLParserDelegate {

    @IBOutlet weak var SidoTextField: UITextField!
    @IBOutlet weak var SigunguTextField: UITextField!
    @IBOutlet weak var CareNameTextField: UITextField!
    
    var selectTextField: UITextField!
    
    let SigunguPicker = UIPickerView()
    let SidoPicker = UIPickerView()

    //Done버튼을 누르면 동작하는 unwind메소드
    //아무 동작도 하지 않지만 이 메소드가 있어야지 DogTableViewController에서 unwind 연결이 가능함
    @IBAction func doneToViewController(segue:UIStoryboardSegue){
        
    }
    
    var SidoSource = ["전체","서울특별시", "부산광역시", "대구광역시", "인천광역시", "광주광역시", "세종특별자치시", "대전광역시", "울산광역시", "경기도", "강원도", "충청북도", "충청남도", "전라북도", "전라남도", "경상북도", "경상남도", "제주특별자치도"]
    var SeoulSource = ["전체","가정보호", "강남구", "강동구", "강북구", "강서구", "관악구", "광진구", "구로구", "금천구",
                       "노원구", "도봉구", "동대문구", "동작구", "마포구", "서대문구", "서초구", "성동구",
                       "성북구", "송파구", "양천구", "영등포구", "용산구", "은평구", "종로구", "중구", "중랑구"]
    var BusanSource = ["전체","강서구", "금정구", "기장군", "남구", "동구", "동래구", "부산진구", "북구", "사상구", "사하구", "서구",
                       "수영구", "연제구", "영도구", "중구", "해운대구"]
    var DaeguSource = ["전체","남구", "달서구", "달성군", "동구", "북구", "서구", "수성구", "중구"]
    var IncheonSource = ["전체","강화군", "계양구", "남구", "남동구", "동구", "부평구", "서구", "연수구", "옹진군", "중구"]
    var GwangjuSource = ["전체","광산구", "남구", "동구", "북구", "서구"]
    var DaejeonSource = ["전체","대덕구", "동구", "서구", "유성구", "중구"]
    var UlsanSource = ["전체","남구", "동구", "북구", "울주군", "중구"]
    var GyeonggiSource = ["전체","가평군", "고양시", "과천시", "광명시", "광주시", "구리시", "군포시", "김포시", "남양주시", "동두천시", "부천시", "성남시", "수원시", "시흥시", "안산시", "안성시", "안양시", "양주시", "양평군", "여주시","연천군", "오산시", "용인시", "용인시 기흥구", "의왕시", "의정부시", "이천시", "파주시", "평택시", "포천시","하남시","화성시"]
    var GangwonSource = ["전체","강릉시", "고성군", "동해시", "삼척시", "속초시", "양구군", "양양군", "영월군", "원주시", "인제군", "정선군",
                         "철원군", "춘천시", "태백시", "평창군", "홍천군", "화천군", "횡성군"]
    var ChungbukSource = ["전체","괴산군", "단양군", "보은군", "영동군", "옥천군", "음성군", "제천시", "증평군", "진천군", "청주시", "충주시"]
    var ChungnamSource = ["전체","계룡시", "공주시", "금산군", "논산시", "당진시", "보령시", "부여군", "서산시", "서천군", "아산시", "연기군",
                          "예산군", "천안시", "청양군", "태안군", "홍성군"]
    var JeonbukSource = ["전체","고창군", "군산시", "김제시", "남원시", "무주군", "부안군", "순창군", "완주군", "익산시", "임실군", "장수군",
                         "전주시", "정읍시", "진안군"]
    var JeonnamSource = ["전체","강진군", "고흥군", "곡성군", "광양시", "구례군", "나주시", "담양군", "목포시", "무안군", "보성군", "순천시",
                         "신안군", "여수시", "영광군", "영암군", "완도군", "장성군", "장흥군", "진도군", "함평군", "해남군", "화순군"]
    var GyeongbukSource = ["전체","경산시", "경주시", "고령군", "구미시", "군위군", "김천시", "문경시", "봉화군", "상주시", "성주군", "안동시",
                           "영덕군", "영양군", "영주시", "영천시", "예천군", "울릉군", "울진군", "의성군", "청도군", "청송군", "칠곡군",
                           "포항시"]
    var GyeongnamSource = ["전체","거제시", "거창군", "고성군", "김해시", "남해군", "밀양시", "사천시", "산청군", "양산시", "의령군", "진주시",
                           "창녕군", "창원 마산합포회원구", "창원 의창성산구", "창원 진해구", "통영시", "하동군", "함안군", "함양군",
                           "합천군"]
    var JejuSource = ["전체","서귀포시", "제주시", "제주특별자치도"]
    
    //보호소정보 OpenAPI 및 인증키
    //serviceKey = "1td22cJml3Qk4BuSNgwhWXUk2xtS8zrLx0n0OfwQHdcn5HvvOvAv9UOJ6qSztOTbtrI5ODfdxzXhgvC5NJWxvQ%3D%3D"
    var url: String = "http://openapi.animal.go.kr/openapi/service/rest/abandonmentPublicSrvc/shelter?serviceKey=1td22cJml3Qk4BuSNgwhWXUk2xtS8zrLx0n0OfwQHdcn5HvvOvAv9UOJ6qSztOTbtrI5ODfdxzXhgvC5NJWxvQ%3D%3D"
    var sido: String = "&upr_cd="
    var sigungu : String = "&org_cd="
    var sidoCd : String = ""
    var sigunguCd : String = ""
    
    //xml파일을 다운로드 및 파싱하는 오브젝트
    var parser = XMLParser()
    var element = NSString()
    
    @IBAction func SetSido(_ sender: Any) {
        selectTextField = SidoTextField
        SidoTextField.tag = 1
        popUpPicker()
    }
    @IBAction func SetSigungu(_ sender: Any) {
        selectTextField = SigunguTextField
        SigunguTextField.tag = 2
        popUpPicker()
    }

    @IBAction func SetName(_ sender: Any) {
        CareNameTextField.resignFirstResponder()
    }
    
    func initPicker() {
        SidoPicker.delegate = self
        SidoPicker.dataSource = self
        SidoPicker.tag = 1
        
        SigunguPicker.delegate = self
        SigunguPicker.dataSource = self
        SigunguPicker.tag = 2
        
        SidoTextField.text = SidoSource[0]
        SigunguTextField.text = SeoulSource[0]
        sidoCd = "6110000"
        sigunguCd = "6119999"
    }
    
    func popUpPicker() {
        if selectTextField.tag == 1 {
            selectTextField.inputView = SidoPicker
        }
        else {
            selectTextField.inputView = SigunguPicker
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    
    //pickerView의 컴포넌트 개수 = 1
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    //pickerView의 각 컴포넌트에 대한 row의 개수 = pickerDataSource 배열 원소 개수
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView.tag == 1 {
            return SidoSource.count
        } else if pickerView.tag == 2 {
            if SidoTextField.text == "서울특별시" {return SeoulSource.count}
            else if SidoTextField.text == "부산광역시"      {return BusanSource.count}
            else if SidoTextField.text == "대구광역시"      {return DaeguSource.count}
            else if SidoTextField.text == "인천광역시"      {return IncheonSource.count}
            else if SidoTextField.text == "광주광역시"      {return GwangjuSource.count}
            else if SidoTextField.text == "대전광역시"      {return DaejeonSource.count}
            else if SidoTextField.text == "울산광역시"      {return UlsanSource.count}
            else if SidoTextField.text == "경기도"         {return GyeonggiSource.count}
            else if SidoTextField.text == "강원도"         {return GangwonSource.count}
            else if SidoTextField.text == "충청북도"       {return ChungbukSource.count}
            else if SidoTextField.text == "충청남도"       {return ChungnamSource.count}
            else if SidoTextField.text == "전라북도"       {return JeonbukSource.count}
            else if SidoTextField.text == "전라남도"       {return JeonnamSource.count}
            else if SidoTextField.text == "경상북도"       {return GyeongbukSource.count}
            else if SidoTextField.text == "경상남도"       {return GyeongnamSource.count}
            else if SidoTextField.text == "제주특별자치도"   {return JejuSource.count}
        }
        return 1
        //return pickerDataSource.count
    }
    //pickerView의 주어진 컴포넌트/row에 대한 데이터 = pickerDataSource 배열의 원소
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView.tag == 1 {
            return SidoSource[row]
        } else if pickerView.tag == 2 {
            if SidoTextField.text == "서울특별시"           {return SeoulSource[row]}
            else if SidoTextField.text == "부산광역시"      {return BusanSource[row]}
            else if SidoTextField.text == "대구광역시"      {return DaeguSource[row]}
            else if SidoTextField.text == "인천광역시"      {return IncheonSource[row]}
            else if SidoTextField.text == "광주광역시"      {return GwangjuSource[row]}
            else if SidoTextField.text == "대전광역시"      {return DaejeonSource[row]}
            else if SidoTextField.text == "울산광역시"      {return UlsanSource[row]}
            else if SidoTextField.text == "경기도"         {return GyeonggiSource[row]}
            else if SidoTextField.text == "강원도"         {return GangwonSource[row]}
            else if SidoTextField.text == "충청북도"       {return ChungbukSource[row]}
            else if SidoTextField.text == "충청남도"       {return ChungnamSource[row]}
            else if SidoTextField.text == "전라북도"       {return JeonbukSource[row]}
            else if SidoTextField.text == "전라남도"       {return JeonnamSource[row]}
            else if SidoTextField.text == "경상북도"       {return GyeongbukSource[row]}
            else if SidoTextField.text == "경상남도"       {return GyeongnamSource[row]}
            else if SidoTextField.text == "제주특별자치도"   {return JejuSource[row]}
        }
        
        return ""
        //return pickerDataSource[row]
    }
    //pickerView의 row 선택시 ogr_cd 를 변경
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
 
        if pickerView.tag == 1 {
            SigunguTextField.isHidden = false
            SigunguTextField.text = "전체"
            
            if row == 0 {
                sidoCd = ""
                sigunguCd = ""
                SigunguTextField.isHidden = true
            }
            else if row == 1 { sidoCd = "6110000" }
            else if row == 2 { sidoCd = "6260000" }
            else if row == 3 { sidoCd = "6270000" }
            else if row == 4 { sidoCd = "6280000" }
            else if row == 5 { sidoCd = "6290000" }
            else if row == 6 { sidoCd = "5690000"; SigunguTextField.isHidden = true }
            else if row == 7 { sidoCd = "6300000"}
            else if row == 8 { sidoCd = "6310000"}
            else if row == 9 { sidoCd = "6410000"}
            else if row == 10 { sidoCd = "6420000"}
            else if row == 11 { sidoCd = "6430000"}
            else if row == 12 { sidoCd = "6440000"}
            else if row == 13 { sidoCd = "6450000"}
            else if row == 14 { sidoCd = "6460000"}
            else if row == 15 { sidoCd = "6470000"}
            else if row == 16 { sidoCd = "6480000"}
            else              { sidoCd = "6500000"}

            
            SidoTextField.text = SidoSource[row]
            SigunguPicker.selectRow(0, inComponent: 0, animated: false)
            sigunguCd = ""
        }
        if pickerView.tag == 2 {
            if sidoCd == "6110000" { // 서울 특별시
                if row == 0 {
                    sigunguCd = ""
                }
                else if row == 1 {
                    sigunguCd = "6119999"
                }
                else if row == 2 {
                    sigunguCd = "3220000"
                }
                else if row == 3 {
                    sigunguCd = "3240000"
                }
                else if row == 4 {
                    sigunguCd = "3080000"
                }
                else if row == 5 {
                    sigunguCd = "3150000"
                }
                else if row == 6 {
                    sigunguCd = "6119998"
                }
                else if row == 7 {
                    sigunguCd = "3200000"
                }
                else if row == 8 {
                    sigunguCd = "3040000"
                }
                else if row == 9 {
                    sigunguCd = "3160000"
                }
                else if row == 10 {
                    sigunguCd = "3170000"
                }
                else if row == 11 {
                    sigunguCd = "3100000"
                }
                else if row == 12 {
                    sigunguCd = "3090000"
                }
                else if row == 13 {
                    sigunguCd = "3050000"
                }
                else if row == 14 {
                    sigunguCd = "3190000"
                }
                else if row == 15 {
                    sigunguCd = "3130000"
                }
                else if row == 16 {
                    sigunguCd = "3120000"
                }
                else if row == 17 {
                    sigunguCd = "3210000"
                }
                else if row == 18 {
                    sigunguCd = "3030000"
                }
                else if row == 19 {
                    sigunguCd = "3070000"
                }
                else if row == 20 {
                    sigunguCd = "3230000"
                }
                else if row == 21 {
                    sigunguCd = "3140000"
                }
                else if row == 22 {
                    sigunguCd = "3180000"
                }
                else if row == 23 {
                    sigunguCd = "3020000"
                }
                else if row == 24 {
                    sigunguCd = "3110000"
                }
                else if row == 25 {
                    sigunguCd = "3000000"
                }
                else if row == 26 {
                    sigunguCd = "3010000"
                }
                else if row == 27 {
                    sigunguCd = "3060000"
                }
                SigunguTextField.text = SeoulSource[row]
            }
                
            else if sidoCd == "6260000" { // 부산 광역시
                if row == 0 {
                    sigunguCd = ""
                }
                else if row == 1 {
                    sigunguCd = "3360000"
                }
                else if row == 2 {
                    sigunguCd = "3350000"
                }
                else if row == 3 {
                    sigunguCd = "3400000"
                }
                else if row == 4 {
                    sigunguCd = "3310000"
                }
                else if row == 5 {
                    sigunguCd = "3270000"
                }
                else if row == 6 {
                    sigunguCd = "3300000"
                }
                else if row == 7 {
                    sigunguCd = "3290000"
                }
                else if row == 8 {
                    sigunguCd = "3320000"
                }
                else if row == 9 {
                    sigunguCd = "3390000"
                }
                else if row == 10 {
                    sigunguCd = "3340000"
                }
                else if row == 11 {
                    sigunguCd = "3260000"
                }
                else if row == 12 {
                    sigunguCd = "3380000"
                }
                else if row == 13 {
                    sigunguCd = "3370000"
                }
                else if row == 14 {
                    sigunguCd = "3280000"
                }
                else if row == 15 {
                    sigunguCd = "3250000"
                }
                else if row == 16 {
                    sigunguCd = "3330000"
                }
                SigunguTextField.text = BusanSource[row]
            }
                
            else if sidoCd == "6270000" { // 대구 광역시
                if row == 0 {
                    sigunguCd = ""
                }
                else if row == 1 {
                    sigunguCd = "3340000"
                }
                else if row == 2 {
                    sigunguCd = "3470000"
                }
                else if row == 3 {
                    sigunguCd = "3480000"
                }
                else if row == 4 {
                    sigunguCd = "3420000"
                }
                else if row == 5 {
                    sigunguCd = "3450000"
                }
                else if row == 6 {
                    sigunguCd = "3430000"
                }
                else if row == 7 {
                    sigunguCd = "3460000"
                }
                else if row == 8 {
                    sigunguCd = "3410000"
                }
                SigunguTextField.text = DaeguSource[row]
            }
                
            else if sidoCd == "6280000" {    // 인천 광역시
                if row == 0 {
                    sigunguCd = ""
                }
                else if row == 1 {
                    sigunguCd = "3570000"
                }
                else if row == 2 {
                    sigunguCd = "3550000"
                }
                else if row == 3 {
                    sigunguCd = "3510000"
                }
                else if row == 4 {
                    sigunguCd = "3530000"
                }
                else if row == 5 {
                    sigunguCd = "3500000"
                }
                else if row == 6 {
                    sigunguCd = "3540000"
                }
                else if row == 7 {
                    sigunguCd = "3560000"
                }
                else if row == 8 {
                    sigunguCd = "3520000"
                }
                else if row == 9 {
                    sigunguCd = "3580000"
                }
                else if row == 10 {
                    sigunguCd = "3490000"
                }
                SigunguTextField.text = IncheonSource[row]
            }
                
            else if sidoCd == "6290000" {    // 광주 광역시
                if row == 0 {
                    sigunguCd = ""
                }
                else if row == 1 {
                    sigunguCd = "3630000"
                }
                else if row == 2 {
                    sigunguCd = "3610000"
                }
                else if row == 3 {
                    sigunguCd = "3590000"
                }
                else if row == 4 {
                    sigunguCd = "3620000"
                }
                else if row == 5 {
                    sigunguCd = "3600000"
                }
                SigunguTextField.text = GwangjuSource[row]
            }
                
            else if sidoCd == "6300000" {    // 대전 광역시
                if row == 0 {
                    sigunguCd = ""
                }
                else if row == 1 {
                    sigunguCd = "3680000"
                }
                else if row == 2 {
                    sigunguCd = "3640000"
                }
                else if row == 3 {
                    sigunguCd = "3660000"
                }
                else if row == 4 {
                    sigunguCd = "3670000"
                }
                else if row == 5 {
                    sigunguCd = "3650000"
                }
                SigunguTextField.text = DaejeonSource[row]
            }
                
            else if sidoCd == "6310000" {    // 울산 광역시
                if row == 0 {
                    sigunguCd = ""
                }
                else if row == 1 {
                    sigunguCd = "3700000"
                }
                else if row == 2 {
                    sigunguCd = "3710000"
                }
                else if row == 3 {
                    sigunguCd = "3720000"
                }
                else if row == 4 {
                    sigunguCd = "3730000"
                }
                else if row == 5 {
                    sigunguCd = "3690000"
                }
                SigunguTextField.text = UlsanSource[row]
            }
                
            else if sidoCd == "6410000" {    // 경기도
                if row == 0 {
                    sigunguCd = ""
                }
                else if row == 1 {
                    sigunguCd = "4160000"
                }
                else if row == 2 {
                    sigunguCd = "3940000"
                }
                else if row == 3 {
                    sigunguCd = "3970000"
                }
                else if row == 4 {
                    sigunguCd = "3900000"
                }
                else if row == 5 {
                    sigunguCd = "5540000"
                }
                else if row == 6 {
                    sigunguCd = "3980000"
                }
                else if row == 7 {
                    sigunguCd = "4020000"
                }
                else if row == 8 {
                    sigunguCd = "49090000"
                }
                else if row == 9 {
                    sigunguCd = "3990000"
                }
                else if row == 10 {
                    sigunguCd = "3920000"
                }
                else if row == 11 {
                    sigunguCd = "3860000"
                }
                else if row == 12 {
                    sigunguCd = "3780000"
                }
                else if row == 13 {
                    sigunguCd = "3740000"
                }
                else if row == 14 {
                    sigunguCd = "4010000"
                }
                else if row == 15 {
                    sigunguCd = "3930000"
                }
                else if row == 16 {
                    sigunguCd = "4080000"
                }
                else if row == 17 {
                    sigunguCd = "3830000"
                }
                else if row == 18 {
                    sigunguCd = "5590000"
                }
                else if row == 19 {
                    sigunguCd = "4170000"
                }
                else if row == 20 {
                    sigunguCd = "5700000"
                }
                else if row == 21 {
                    sigunguCd = "4140000"
                }
                else if row == 22 {
                    sigunguCd = "4000000"
                }
                else if row == 23 {
                    sigunguCd = "4050000"
                }
                else if row == 24 {
                    sigunguCd = "5630000"
                }
                else if row == 25 {
                    sigunguCd = "4030000"
                }
                else if row == 26 {
                    sigunguCd = "3820000"
                }
                else if row == 27 {
                    sigunguCd = "4070000"
                }
                else if row == 28 {
                    sigunguCd = "4060000"
                }
                else if row == 29 {
                    sigunguCd = "3910000"
                }
                else if row == 30 {
                    sigunguCd = "5600000"
                }
                else if row == 31 {
                    sigunguCd = "4040000"
                }
                else if row == 32 {
                    sigunguCd = "5530000"
                }
                SigunguTextField.text = GyeonggiSource[row]
            }
            
            if sidoCd == "6420000" { // 강원도
                if row == 0 {
                    sigunguCd = ""
                }
                else if row == 1 {
                    sigunguCd = "4200000"
                }
                else if row == 2 {
                    sigunguCd = "4340000"
                }
                else if row == 3 {
                    sigunguCd = "4210000"
                }
                else if row == 4 {
                    sigunguCd = "4240000"
                }
                else if row == 5 {
                    sigunguCd = "4230000"
                }
                else if row == 6 {
                    sigunguCd = "4320000"
                }
                else if row == 7 {
                    sigunguCd = "4350000"
                }
                else if row == 8 {
                    sigunguCd = "4270000"
                }
                else if row == 9 {
                    sigunguCd = "4190000"
                }
                else if row == 10 {
                    sigunguCd = "4330000"
                }
                else if row == 11 {
                    sigunguCd = "4290000"
                }
                else if row == 12 {
                    sigunguCd = "4300000"
                }
                else if row == 13 {
                    sigunguCd = "4180000"
                }
                else if row == 14 {
                    sigunguCd = "4220000"
                }
                else if row == 15 {
                    sigunguCd = "4280000"
                }
                else if row == 16 {
                    sigunguCd = "4250000"
                }
                else if row == 17 {
                    sigunguCd = "4310000"
                }
                else if row == 18 {
                    sigunguCd = "4260000"
                }
                SigunguTextField.text = GangwonSource[row]
            }
            else if sidoCd == "6430000" { // 충청북도
                if row == 0 {
                    sigunguCd = ""
                }
                else if row == 1 {
                    sigunguCd = "4460000"
                }
                else if row == 2 {
                    sigunguCd = "4480000"
                }
                else if row == 3 {
                    sigunguCd = "4420000"
                }
                else if row == 4 {
                    sigunguCd = "4440000"
                }
                else if row == 5 {
                    sigunguCd = "4430000"
                }
                else if row == 6 {
                    sigunguCd = "4470000"
                }
                else if row == 7 {
                    sigunguCd = "4400000"
                }
                else if row == 8 {
                    sigunguCd = "5570000"
                }
                else if row == 9 {
                    sigunguCd = "4450000"
                }
                else if row == 10 {
                    sigunguCd = "5710000"
                }
                else if row == 11 {
                    sigunguCd = "4390000"
                }
                SigunguTextField.text = ChungbukSource[row]
            }
                
            else if sidoCd == "6440000" { // 충청남도
                if row == 0 {
                    sigunguCd = ""
                }
                else if row == 1 {
                    sigunguCd = "5580000"
                }
                else if row == 2 {
                    sigunguCd = "4500000"
                }
                else if row == 3 {
                    sigunguCd = "4550000"
                }
                else if row == 4 {
                    sigunguCd = "4540000"
                }
                else if row == 5 {
                    sigunguCd = "5680000"
                }
                else if row == 6 {
                    sigunguCd = "4510000"
                }
                else if row == 7 {
                    sigunguCd = "4570000"
                }
                else if row == 8 {
                    sigunguCd = "4530000"
                }
                else if row == 9 {
                    sigunguCd = "4580000"
                }
                else if row == 10 {
                    sigunguCd = "4520000"
                }
                else if row == 11 {
                    sigunguCd = "4560000"
                }
                else if row == 12 {
                    sigunguCd = "4610000"
                }
                else if row == 13 {
                    sigunguCd = "4490000"
                }
                else if row == 14 {
                    sigunguCd = "4590000"
                }
                else if row == 15 {
                    sigunguCd = "4620000"
                }
                else if row == 16 {
                    sigunguCd = "4600000"
                }
                SigunguTextField.text = ChungnamSource[row]
            }
                
            else if sidoCd == "6450000" { // 전라북도
                if row == 0 {
                    sigunguCd = ""
                }
                else if row == 1 {
                    sigunguCd = "4780000"
                }
                else if row == 2 {
                    sigunguCd = "4670000"
                }
                else if row == 3 {
                    sigunguCd = "4710000"
                }
                else if row == 4 {
                    sigunguCd = "4700000"
                }
                else if row == 5 {
                    sigunguCd = "4740000"
                }
                else if row == 6 {
                    sigunguCd = "4790000"
                }
                else if row == 7 {
                    sigunguCd = "4770000"
                }
                else if row == 8 {
                    sigunguCd = "4720000"
                }
                else if row == 9 {
                    sigunguCd = "4680000"
                }
                else if row == 10 {
                    sigunguCd = "4760000"
                }
                else if row == 11 {
                    sigunguCd = "4750000"
                }
                else if row == 12 {
                    sigunguCd = "4640000"
                }
                else if row == 13 {
                    sigunguCd = "4690000"
                }
                else if row == 14 {
                    sigunguCd = "4730000"
                }
                SigunguTextField.text = JeonbukSource[row]
            }
                
            else if sidoCd == "6460000" { // 전라남도
                if row == 0 {
                    sigunguCd = ""
                }
                else if row == 1 {
                    sigunguCd = "4920000"
                }
                else if row == 2 {
                    sigunguCd = "4880000"
                }
                else if row == 3 {
                    sigunguCd = "4860000"
                }
                else if row == 4 {
                    sigunguCd = "4840000"
                }
                else if row == 5 {
                    sigunguCd = "4870000"
                }
                else if row == 6 {
                    sigunguCd = "4830000"
                }
                else if row == 7 {
                    sigunguCd = "4850000"
                }
                else if row == 8 {
                    sigunguCd = "4800000"
                }
                else if row == 9 {
                    sigunguCd = "4950000"
                }
                else if row == 10 {
                    sigunguCd = "4890000"
                }
                else if row == 11 {
                    sigunguCd = "4820000"
                }
                else if row == 12 {
                    sigunguCd = "5010000"
                }
                else if row == 13 {
                    sigunguCd = "4810000"
                }
                else if row == 14 {
                    sigunguCd = "4970000"
                }
                else if row == 15 {
                    sigunguCd = "4940000"
                }
                else if row == 16 {
                    sigunguCd = "4990000"
                }
                else if row == 17 {
                    sigunguCd = "4980000"
                }
                else if row == 18 {
                    sigunguCd = "4910000"
                }
                else if row == 19 {
                    sigunguCd = "5000000"
                }
                else if row == 20 {
                    sigunguCd = "4960000"
                }
                else if row == 21 {
                    sigunguCd = "4930000"
                }
                else if row == 22 {
                    sigunguCd = "4900000"
                }
                SigunguTextField.text = JeonnamSource[row]
            }
                
            else if sidoCd == "6470000" { // 경상북도
                if row == 0 {
                    sigunguCd = ""
                }
                else if row == 1 {
                    sigunguCd = "5130000"
                }
                else if row == 2 {
                    sigunguCd = "5050000"
                }
                else if row == 3 {
                    sigunguCd = "5200000"
                }
                else if row == 4 {
                    sigunguCd = "5080000"
                }
                else if row == 5 {
                    sigunguCd = "5140000"
                }
                else if row == 6 {
                    sigunguCd = "5060000"
                }
                else if row == 7 {
                    sigunguCd = "5120000"
                }
                else if row == 8 {
                    sigunguCd = "5240000"
                }
                else if row == 9 {
                    sigunguCd = "5110000"
                }
                else if row == 10 {
                    sigunguCd = "5210000"
                }
                else if row == 11 {
                    sigunguCd = "5070000"
                }
                else if row == 12 {
                    sigunguCd = "5180000"
                }
                else if row == 13 {
                    sigunguCd = "5170000"
                }
                else if row == 14 {
                    sigunguCd = "5090000"
                }
                else if row == 15 {
                    sigunguCd = "5100000"
                }
                else if row == 16 {
                    sigunguCd = "5230000"
                }
                else if row == 17 {
                    sigunguCd = "5260000"
                }
                else if row == 18 {
                    sigunguCd = "5250000"
                }
                else if row == 19 {
                    sigunguCd = "5150000"
                }
                else if row == 20 {
                    sigunguCd = "5190000"
                }
                else if row == 21 {
                    sigunguCd = "5160000"
                }
                else if row == 22 {
                    sigunguCd = "5220000"
                }
                else if row == 23 {
                    sigunguCd = "5020000"
                }
                SigunguTextField.text = GyeongbukSource[row]
            }
                
            else if sidoCd == "6480000" { // 경상남도
                if row == 0 {
                    sigunguCd = ""
                }
                else if row == 1 {
                    sigunguCd = "5370000"
                }
                else if row == 2 {
                    sigunguCd = "5470000"
                }
                else if row == 3 {
                    sigunguCd = "5420000"
                }
                else if row == 4 {
                    sigunguCd = "5350000"
                }
                else if row == 5 {
                    sigunguCd = "5430000"
                }
                else if row == 6 {
                    sigunguCd = "5360000"
                }
                else if row == 7 {
                    sigunguCd = "5340000"
                }
                else if row == 8 {
                    sigunguCd = "5450000"
                }
                else if row == 9 {
                    sigunguCd = "5380000"
                }
                else if row == 10 {
                    sigunguCd = "5390000"
                }
                else if row == 11 {
                    sigunguCd = "5310000"
                }
                else if row == 12 {
                    sigunguCd = "5410000"
                }
                else if row == 13 {
                    sigunguCd = "5280000"
                }
                else if row == 14 {
                    sigunguCd = "5670000"
                }
                else if row == 15 {
                    sigunguCd = "5320000"
                }
                else if row == 16 {
                    sigunguCd = "5330000"
                }
                else if row == 17 {
                    sigunguCd = "5440000"
                }
                else if row == 18 {
                    sigunguCd = "5400000"
                }
                else if row == 19 {
                    sigunguCd = "5460000"
                }
                else if row == 20 {
                    sigunguCd = "5480000"
                }
                SigunguTextField.text = GyeongnamSource[row]
            }
            else if sidoCd == "6500000" { // 제주특별시
                if row == 0 {
                    sigunguCd = ""
                }
                else if row == 1 {
                    sigunguCd = "6520000"
                }
                else if row == 2 {
                    sigunguCd = "6510000"
                }
                else if row == 3 {
                    sigunguCd = "6500000"
                }
                SigunguTextField.text = JejuSource[row]
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initPicker()
    }
    //prepare 메소드는 segue 실행될 때 호출되는 메소드
    //id를 segueToTableView로 설정
    //DogTableViewController에 url 정보 전달하기 위해서 먼저 UINavigationController를
    //destination으로 설정한 후 DogTableViewController 를 선택함
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segueToTableView" {
            if let navController = segue.destination as? UINavigationController {
                if let shelterTableviewController = navController.topViewController as?
                    ShelterTableViewController {
                    shelterTableviewController.url = url + sido + sidoCd + sigungu + sigunguCd
                    shelterTableviewController.keyword = CareNameTextField.text!
                    print("viewController url: ")
                    print(String(shelterTableviewController.url!))
                }
            }
        }
    }
}

