//
//  ViewController.swift
//  SearchPet
//
//  Created by KPUGAME on 2019. 5. 15..
//  Copyright © 2019년 BAEJISOO. All rights reserved.
//

import UIKit

class LogoController: UIViewController {

    var audioController: AudioController
    required init?(coder aDecoder: NSCoder) {
        audioController = AudioController()
        audioController.preloadAudioEffects(audioFileNames: AudioEffectFiles)
        
        super.init(coder: aDecoder)
    }
    
    @IBOutlet weak var StartButton: UIButton!
    @IBAction func StartApp(_ sender: Any) {
        audioController.playerEffect(name: SoundDing)
        // particle
        let explore = ExplodeView(frame: CGRect(x: StartButton.center.x , y: StartButton.center.y, width: 10, height: 10))
        StartButton.superview?.addSubview(explore)
        StartButton.superview?.addSubview(_: explore)
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
}

